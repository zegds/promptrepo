let config = {};
let selectedFolder = null;
let selectedPrompt = null;

window.onload = async () => {
  const res = await fetch('/get_config');
  config = await res.json();
  renderFolders();
  renderPrompts();
};

function renderFolders() {
  const list = document.getElementById('folder-list');
  list.innerHTML = '';
  for (const folder in config.folders) {
    const li = document.createElement('li');
    li.className = 'folder-item';
    li.innerHTML = `<img src="/static/icons/folder.svg"><span>${folder}</span> <button onclick="renameFolderPrompt('${folder}')">✏️</button>`;
    li.onclick = () => {
      selectedFolder = folder;
      renderPrompts();
    };
    li.ondrop = dropPrompt;
    li.ondragover = (e) => e.preventDefault();
    list.appendChild(li);
  }
}

function renameFolderPrompt(folder) {
  const newName = prompt("Rename folder:", folder);
  if (newName && newName !== folder && !config.folders[newName]) {
    config.folders[newName] = config.folders[folder];
    delete config.folders[folder];
    if (selectedFolder === folder) selectedFolder = newName;
    saveConfig();
    renderFolders();
  }
}

function renderPrompts() {
  const container = document.getElementById('prompt-list');
  container.innerHTML = '';
  const prompts = selectedFolder ? config.folders[selectedFolder] : config.root_prompts;
  prompts.forEach((prompt, idx) => {
    const div = document.createElement('div');
    div.classList.add('prompt-item');
    div.setAttribute('draggable', true);
    div.dataset.index = idx;
    div.dataset.folder = selectedFolder;
    div.ondragstart = dragPrompt;

    div.innerHTML = `
      <b>${prompt.title}</b>
      <button onclick="editPrompt(${idx})">Edit</button>
      <button onclick="copyPrompt(${idx})">Copy</button>
      <button onclick="confirmDeletePrompt(${idx})">🗑️</button>
    `;
    container.appendChild(div);
  });
}

function dragPrompt(event) {
  const index = event.target.dataset.index;
  const folder = event.target.dataset.folder;
  event.dataTransfer.setData("text/plain", JSON.stringify({ index, folder }));
}

function dropPrompt(event) {
  event.preventDefault();
  const data = JSON.parse(event.dataTransfer.getData("text/plain"));
  const fromFolder = data.folder;
  const index = data.index;
  const prompt = fromFolder ? config.folders[fromFolder][index] : config.root_prompts[index];

  const toFolder = event.target.innerText;
  if (!config.folders[toFolder]) return;

  if (fromFolder) config.folders[fromFolder].splice(index, 1);
  else config.root_prompts.splice(index, 1);

  config.folders[toFolder].push(prompt);

  saveConfig();
  renderFolders();
  renderPrompts();
}

function addFolder() {
  const name = prompt("Folder name:");
  if (name && !config.folders[name]) {
    config.folders[name] = [];
    saveConfig();
    renderFolders();
  }
}

function addPrompt() {
  selectedPrompt = null;
  document.getElementById('prompt-title').value = '';
  document.getElementById('prompt-text').value = '';
  document.getElementById('prompt-editor').style.display = 'block';
}

function editPrompt(index) {
  selectedPrompt = index;
  const prompts = selectedFolder ? config.folders[selectedFolder] : config.root_prompts;
  const prompt = prompts[index];
  document.getElementById('prompt-title').value = prompt.title;
  document.getElementById('prompt-text').value = prompt.text;
  document.getElementById('prompt-editor').style.display = 'block';
}

function savePrompt() {
  const title = document.getElementById('prompt-title').value;
  const text = document.getElementById('prompt-text').value;
  const prompts = selectedFolder ? config.folders[selectedFolder] : config.root_prompts;

  if (selectedPrompt != null) {
    prompts[selectedPrompt] = { title, text };
  } else {
    prompts.push({ title, text });
  }

  document.getElementById('prompt-editor').style.display = 'none';
  saveConfig();
  renderPrompts();
}

function copyPrompt(index) {
  const prompts = selectedFolder ? config.folders[selectedFolder] : config.root_prompts;
  navigator.clipboard.writeText(prompts[index].text);
}

function confirmDeletePrompt(index) {
  const prompts = selectedFolder ? config.folders[selectedFolder] : config.root_prompts;
  if (confirm("Are you sure you want to delete this prompt?")) {
    prompts.splice(index, 1);
    saveConfig();
    renderPrompts();
  }
}

function searchPrompts() {
  const term = document.getElementById('search-bar').value.toLowerCase();
  const results = [];

  for (const folder in config.folders) {
    for (const prompt of config.folders[folder]) {
      if (prompt.title.toLowerCase().includes(term) || prompt.text.toLowerCase().includes(term)) {
        results.push(prompt);
      }
    }
  }

  for (const prompt of config.root_prompts) {
    if (prompt.title.toLowerCase().includes(term) || prompt.text.toLowerCase().includes(term)) {
      results.push(prompt);
    }
  }

  const container = document.getElementById('prompt-list');
  container.innerHTML = '';
  results.forEach(prompt => {
    const div = document.createElement('div');
    div.innerHTML = `<b>${prompt.title}</b><pre>${prompt.text}</pre>`;
    container.appendChild(div);
  });
}

async function saveConfig() {
  await fetch('/save_config', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(config)
  });
}