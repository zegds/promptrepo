let config = {};
let selectedFolder = null;
let selectedPrompt = null;
let expandedFolders = {};

window.onload = async () => {
  const res = await fetch('/get_config');
  config = await res.json();
  renderSidebar();
};

function renderSidebar() {
  const list = document.getElementById('folder-list');
  list.innerHTML = '';

  for (const folder in config.folders) {
    const isOpen = expandedFolders[folder] ?? false;
    const folderEl = document.createElement('div');
    folderEl.className = 'folder-item';
    folderEl.innerHTML = `📂 ${folder} <button onclick="renameFolderPrompt('${folder}')">✏️</button>`;
    folderEl.onclick = () => {
      selectedFolder = folder;
      expandedFolders[folder] = !isOpen;
      renderSidebar();
      renderPrompts();
    };
    list.appendChild(folderEl);

    if (isOpen) {
      config.folders[folder].forEach((p, i) => {
        const pEl = document.createElement('div');
        pEl.className = 'prompt-subitem';
        pEl.innerText = `📝 ${p.title}`;
        pEl.onclick = () => showPromptDetail(p);
        list.appendChild(pEl);
      });
    }
  }

  // Floating prompts (not in any folder)
  if (config.root_prompts.length > 0) {
    const floatHeader = document.createElement('div');
    floatHeader.className = 'folder-item';
    floatHeader.innerText = '📄 Floating Prompts';
    list.appendChild(floatHeader);

    config.root_prompts.forEach((p, i) => {
      const pEl = document.createElement('div');
      pEl.className = 'prompt-subitem';
      pEl.innerText = `📝 ${p.title}`;
      pEl.onclick = () => showPromptDetail(p);
      list.appendChild(pEl);
    });
  }
}

function showPromptDetail(prompt) {
  const container = document.getElementById('prompt-list');
  container.innerHTML = `<h3>${prompt.title}</h3><pre>${prompt.text}</pre>`;
}

function renameFolderPrompt(folder) {
  const newName = prompt("Rename folder:", folder);
  if (newName && newName !== folder && !config.folders[newName]) {
    config.folders[newName] = config.folders[folder];
    delete config.folders[folder];
    if (selectedFolder === folder) selectedFolder = newName;
    saveConfig();
    renderSidebar();
  }
}

function addFolder() {
  const name = prompt("Folder name:");
  if (name && !config.folders[name]) {
    config.folders[name] = [];
    saveConfig();
    renderSidebar();
  }
}

function addPrompt() {
  selectedPrompt = null;
  document.getElementById('prompt-title').value = '';
  document.getElementById('prompt-text').value = '';
  document.getElementById('prompt-editor').style.display = 'block';
}

function savePrompt() {
  const title = document.getElementById('prompt-title').value;
  const text = document.getElementById('prompt-text').value;
  const assignToFolder = selectedFolder;

  if (selectedPrompt != null) {
    // Editing prompt
  } else {
    const newPrompt = { title, text };
    if (assignToFolder && config.folders[assignToFolder]) {
      config.folders[assignToFolder].push(newPrompt);
    } else {
      config.root_prompts.push(newPrompt);
    }
  }

  document.getElementById('prompt-editor').style.display = 'none';
  saveConfig();
  renderSidebar();
}

async function saveConfig() {
  await fetch('/save_config', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(config)
  });
}

function renderPrompts() {
  const container = document.getElementById('prompt-list');
  container.innerHTML = '';
}// Reordering logic for drag and drop of folders and prompts
function enableDragAndDropReordering() {
  const folderItems = document.querySelectorAll('.folder-item');
  folderItems.forEach(item => {
    item.setAttribute('draggable', true);
    item.addEventListener('dragstart', (e) => {
      e.dataTransfer.setData('folder', item.querySelector('span').innerText);
    });
    item.addEventListener('dragover', (e) => e.preventDefault());
    item.addEventListener('drop', (e) => {
      const fromFolder = e.dataTransfer.getData('folder');
      const toFolder = item.querySelector('span').innerText;
      reorderFolders(fromFolder, toFolder);
    });
  });

  const promptItems = document.querySelectorAll('.prompt-subitem');
  promptItems.forEach((item, index) => {
    item.setAttribute('draggable', true);
    item.addEventListener('dragstart', (e) => {
      e.dataTransfer.setData('promptIndex', index);
      e.dataTransfer.setData('folderContext', selectedFolder || '');
    });
    item.addEventListener('dragover', (e) => e.preventDefault());
    item.addEventListener('drop', (e) => {
      const fromIndex = parseInt(e.dataTransfer.getData('promptIndex'));
      const folderContext = e.dataTransfer.getData('folderContext') || null;
      const toIndex = index;
      reorderPrompts(folderContext, fromIndex, toIndex);
    });
  });
}

function reorderFolders(from, to) {
  if (from === to) return;
  const keys = Object.keys(config.folders);
  const newKeys = keys.filter(k => k !== from);
  const idx = newKeys.indexOf(to);
  newKeys.splice(idx, 0, from);

  const newFolders = {};
  newKeys.forEach(k => {
    newFolders[k] = config.folders[k];
  });

  config.folders = newFolders;
  saveConfig();
  renderSidebar();
}

function reorderPrompts(folder, fromIdx, toIdx) {
  const list = folder ? config.folders[folder] : config.root_prompts;
  const item = list.splice(fromIdx, 1)[0];
  list.splice(toIdx, 0, item);
  saveConfig();
  renderSidebar();
}

setTimeout(() => {
  enableDragAndDropReordering();
}, 500);function enableNestedDragAndDrop() {
  document.querySelectorAll('.folder-item').forEach(folderEl => {
    const folderName = folderEl.querySelector('span').innerText;

    folderEl.setAttribute('draggable', true);
    folderEl.addEventListener('dragstart', (e) => {
      e.dataTransfer.setData('drag-type', 'folder');
      e.dataTransfer.setData('folder', folderName);
    });

    folderEl.addEventListener('dragover', (e) => e.preventDefault());

    folderEl.addEventListener('drop', (e) => {
      e.preventDefault();
      const dragType = e.dataTransfer.getData('drag-type');

      if (dragType === 'folder') {
        const fromFolder = e.dataTransfer.getData('folder');
        if (fromFolder !== folderName && config.folders[fromFolder] && config.folders[folderName]) {
          if (!config.folders[folderName].subfolders) config.folders[folderName].subfolders = {};
          config.folders[folderName].subfolders[fromFolder] = config.folders[fromFolder];
          delete config.folders[fromFolder];
          saveConfig();
          renderSidebar();
        }
      } else if (dragType === 'prompt') {
        const fromFolder = e.dataTransfer.getData('folderContext') || null;
        const promptIndex = parseInt(e.dataTransfer.getData('promptIndex'));
        const list = fromFolder ? config.folders[fromFolder] : config.root_prompts;
        const prompt = list.splice(promptIndex, 1)[0];

        if (config.folders[folderName]) {
          config.folders[folderName].push(prompt);
        }

        saveConfig();
        renderSidebar();
      }
    });
  });

  document.querySelectorAll('.prompt-subitem').forEach((item, index) => {
    item.setAttribute('draggable', true);
    item.addEventListener('dragstart', (e) => {
      e.dataTransfer.setData('drag-type', 'prompt');
      e.dataTransfer.setData('promptIndex', index);
      e.dataTransfer.setData('folderContext', selectedFolder || '');
    });
  });
}

setTimeout(() => {
  enableNestedDragAndDrop();
}, 500);function renderSidebar(container = document.getElementById('folder-list'), folders = config.folders, depth = 1) {
  container.innerHTML = '';

  for (const folder in folders) {
    const isOpen = expandedFolders[folder] ?? false;
    const folderEl = document.createElement('div');
    folderEl.className = 'folder-item';
    folderEl.setAttribute('style', `--depth: ${depth}`);
    folderEl.setAttribute('data-depth', depth);
    folderEl.innerHTML = `📂 <span>${folder}</span> <button onclick="renameFolderPrompt('${folder}')">✏️</button>`;

    folderEl.onclick = (e) => {
      e.stopPropagation();
      selectedFolder = folder;
      expandedFolders[folder] = !isOpen;
      renderSidebar(container, folders, depth);
      renderPrompts();
    };

    folderEl.ondragover = (e) => e.preventDefault();
    folderEl.ondrop = (e) => handleDrop(e, folder);

    container.appendChild(folderEl);

    if (isOpen) {
      const prompts = folders[folder];
      prompts.forEach((p, i) => {
        const promptEl = document.createElement('div');
        promptEl.className = 'prompt-subitem';
        promptEl.setAttribute('data-depth', depth + 1);
        promptEl.setAttribute('draggable', true);
        promptEl.innerText = `📝 ${p.title}`;
        promptEl.ondragstart = (e) => {
          e.dataTransfer.setData('drag-type', 'prompt');
          e.dataTransfer.setData('promptIndex', i);
          e.dataTransfer.setData('folderContext', folder);
        };
        promptEl.onclick = () => showPromptDetail(p);
        container.appendChild(promptEl);
      });

      // Render subfolders recursively if any
      if (folders[folder].subfolders) {
        renderSidebar(container, folders[folder].subfolders, depth + 1);
      }
    }
  }

  // Floating prompts
  if (depth === 1 && config.root_prompts.length > 0) {
    const floatHeader = document.createElement('div');
    floatHeader.className = 'folder-item';
    floatHeader.innerText = '📄 Floating Prompts';
    floatHeader.setAttribute('style', `--depth: ${depth}`);
    container.appendChild(floatHeader);

    config.root_prompts.forEach((p, i) => {
      const pEl = document.createElement('div');
      pEl.className = 'prompt-subitem';
      pEl.setAttribute('data-depth', depth + 1);
      pEl.innerText = `📝 ${p.title}`;
      pEl.setAttribute('draggable', true);
      pEl.ondragstart = (e) => {
        e.dataTransfer.setData('drag-type', 'prompt');
        e.dataTransfer.setData('promptIndex', i);
        e.dataTransfer.setData('folderContext', '');
      };
      pEl.onclick = () => showPromptDetail(p);
      container.appendChild(pEl);
    });
  }
}

function handleDrop(e, targetFolder) {
  e.preventDefault();
  const dragType = e.dataTransfer.getData('drag-type');

  if (dragType === 'folder') {
    const fromFolder = e.dataTransfer.getData('folder');
    if (fromFolder !== targetFolder && config.folders[fromFolder] && config.folders[targetFolder]) {
      if (!config.folders[targetFolder].subfolders) config.folders[targetFolder].subfolders = {};
      config.folders[targetFolder].subfolders[fromFolder] = config.folders[fromFolder];
      delete config.folders[fromFolder];
      saveConfig();
      renderSidebar();
    }
  } else if (dragType === 'prompt') {
    const fromFolder = e.dataTransfer.getData('folderContext') || null;
    const promptIndex = parseInt(e.dataTransfer.getData('promptIndex'));
    const sourceList = fromFolder ? config.folders[fromFolder] : config.root_prompts;
    const prompt = sourceList.splice(promptIndex, 1)[0];

    if (config.folders[targetFolder]) {
      config.folders[targetFolder].push(prompt);
    }

    saveConfig();
    renderSidebar();
  }
}

setTimeout(() => {
  renderSidebar();
}, 500);