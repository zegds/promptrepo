function renderSidebar(container = document.getElementById('folder-list'), folders = config.folders, depth = 0) {
  container.innerHTML = '';

  for (const folder in folders) {
    const isOpen = expandedFolders[folder] ?? false;
    const folderDiv = document.createElement('div');
    folderDiv.className = 'folder-item';
    folderDiv.setAttribute('data-depth', depth);

    const folderLine = document.createElement('div');
    folderLine.className = 'folder-line';

    const toggle = document.createElement('span');
    toggle.className = 'folder-toggle';
    toggle.innerText = isOpen ? '▼' : '▶';
    toggle.onclick = (e) => {
      e.stopPropagation();
      expandedFolders[folder] = !isOpen;
      renderSidebar();
    };

    const label = document.createElement('span');
    label.className = 'folder-label';
    label.innerText = `📂 ${folder}`;
    label.onclick = () => {
      selectedFolder = folder;
      renderPrompts();
    };

    const renameBtn = document.createElement('button');
    renameBtn.innerText = '✏️';
    renameBtn.onclick = (e) => {
      e.stopPropagation();
      renameFolderPrompt(folder);
    };

    folderLine.appendChild(toggle);
    folderLine.appendChild(label);
    folderLine.appendChild(renameBtn);
    folderDiv.appendChild(folderLine);
    container.appendChild(folderDiv);

    if (isOpen) {
      const promptSublist = document.createElement('div');
      promptSublist.className = 'folder-sublist';

      folders[folder].forEach((p, i) => {
        const promptEl = document.createElement('div');
        promptEl.className = 'prompt-subitem';
        promptEl.innerText = `📝 ${p.title}`;
        promptEl.setAttribute('draggable', true);
        promptEl.ondragstart = (e) => {
          e.dataTransfer.setData('drag-type', 'prompt');
          e.dataTransfer.setData('promptIndex', i);
          e.dataTransfer.setData('folderContext', folder);
        };
        promptEl.onclick = () => showPromptDetail(p);
        promptSublist.appendChild(promptEl);
      });

      if (folders[folder].subfolders) {
        const subfolderContainer = document.createElement('div');
        renderSidebar(subfolderContainer, folders[folder].subfolders, depth + 1);
        promptSublist.appendChild(subfolderContainer);
      }

      container.appendChild(promptSublist);
    }
  }

  if (depth === 0 && config.root_prompts?.length > 0) {
    const floatHeader = document.createElement('div');
    floatHeader.className = 'folder-line';
    floatHeader.innerText = '📄 Floating Prompts';
    container.appendChild(floatHeader);

    config.root_prompts.forEach((p, i) => {
      const pEl = document.createElement('div');
      pEl.className = 'prompt-subitem';
      pEl.innerText = `📝 ${p.title}`;
      pEl.setAttribute('draggable', true);
      pEl.ondragstart = (e) => {
        e.dataTransfer.setData('drag-type', 'prompt');
        e.dataTransfer.setData('promptIndex', i);
        e.dataTransfer.setData('folderContext', '');
      };
      pEl.onclick = () => showPromptDetail(p);
      container.appendChild(pEl);
    });
  }
}

setTimeout(() => {
  renderSidebar();
}, 500);